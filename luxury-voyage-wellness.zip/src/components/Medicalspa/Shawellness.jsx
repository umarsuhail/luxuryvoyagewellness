import React, { Component } from 'react'
import View from './Components/View'
export default class Shawellness extends Component {
    render() {
        return (
            <div>
                <View>
                    
                </View>
            </div>
        )
    }
}
