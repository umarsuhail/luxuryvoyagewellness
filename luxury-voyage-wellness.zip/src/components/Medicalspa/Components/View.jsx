import React, { Component } from 'react'
import BacgroundImage from '../../../images/sha-wellness.jpg'
export default class View extends Component {
    render() {
        return (
            <div>
                <div className="header container-fluid">
                    <img src={BacgroundImage} alt="backround-image"></img>
                </div>
            </div>
        )
    }
}
