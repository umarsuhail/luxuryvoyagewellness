import React, { Component } from 'react'

export default class MedicalSpa extends Component {
    render() {
        return (
            <div>
                
            </div>
        )
    }
}
